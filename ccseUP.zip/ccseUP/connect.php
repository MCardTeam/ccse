<?php
$con=mysqli_connect("localhost","root","","ccse") or die("Not Connect");