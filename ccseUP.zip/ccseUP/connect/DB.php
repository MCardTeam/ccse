<?php

/**
 * 
 */
class DB 
{
	private $db;
	function __construct()
	{
		# code...
		$this->db=new PDO("mysql:host=localhost;dbname=ccse","root","");
	}

	
public function login($id,$pass){
	$sql=$this->db->prepare("SELECT * FROM user WHERE id=? AND pass=?");
	$sql->execute(array($id,$pass));
	if ($sql->rowCount()==1) {
		foreach ($sql as $key ) {
			if ($key['role']==1) {
				$_SESSION['id']=$id;
				$_SESSION['pass']=$pass;
			
				header("index.php");
			}
			else if($key["role"]==2){
				$_SESSION['id']=$id;
				$_SESSION['pass']=$pass;
	

				header("\index.php");

			}
		}
	}
}

